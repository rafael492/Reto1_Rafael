package org.example;

import org.w3c.dom.ls.LSOutput;

public class Main {
    public static void main(String[] args) {
        String fecha;

        fecha = "27/04/1992";
        System.out.println("la fecha de nacimiento de Rafael es: " + fecha);
    }

}